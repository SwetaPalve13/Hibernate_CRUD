package com.example.CRUD;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class PhonebookDAO {

    private final SessionFactory factory;

    // Constructor: Load configuration and map entity
    public PhonebookDAO() {
        factory = new Configuration()
                .configure("hibernate.cfg.xml") // Make sure this file is in your classpath
                .addAnnotatedClass(Contact.class)
                .buildSessionFactory();
    }

    // Add a new contact
    public void addContact(Contact contact) {
        Session session = factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(contact);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    // Retrieve all contacts
    public List<Contact> getAllContacts() {
        Session session = factory.openSession();
        Transaction tx = null;
        List<Contact> contacts = null;
        try {
            tx = session.beginTransaction();
            contacts = session.createQuery("from Contact", Contact.class).list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
        return contacts;
    }

    // Update phone number of a contact
    public void updateContact(int id, String newPhone) {
        Session session = factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Contact contact = session.get(Contact.class, id);
            if (contact != null) {
                contact.setPhone(newPhone);
                session.update(contact);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    // Delete a contact
    public void deleteContact(int id) {
        Session session = factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Contact contact = session.get(Contact.class, id);
            if (contact != null) {
                session.delete(contact);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    // Close the session factory (call at application end)
    public void close() {
        factory.close();
    }
}
