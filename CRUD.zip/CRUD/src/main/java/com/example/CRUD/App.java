package com.example.CRUD;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Phonebook Management ---");
            System.out.println("1. Add Contact");
            System.out.println("2. Delete Contact");
            System.out.println("3. Update Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addContact(sc);
                    break;
                case 2:
                    deleteContact(sc);
                    break;
                case 3:
                    updateContact(sc);
                    break;
                case 4:
                    displayContacts();
                    break;
                case 5:
                    System.out.println("Exiting... 👋");
                    HibernateUtil.getSessionFactory().close();
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 5);
    }

    private static void addContact(Scanner sc) {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter phone: ");
        String phone = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();

        Contact contact = new Contact();
        contact.setName(name);
        contact.setPhone(phone);
        contact.setEmail(email);

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(contact);
        tx.commit();
        session.close();

        System.out.println("Contact added successfully!");
    }

    private static void deleteContact(Scanner sc) {
        System.out.print("Enter ID to delete: ");
        int id = sc.nextInt();

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Contact contact = session.get(Contact.class, id);
        if (contact != null) {
            session.delete(contact);
            System.out.println("Contact deleted successfully!");
        } else {
            System.out.println("Contact not found.");
        }
        tx.commit();
        session.close();
    }

    private static void updateContact(Scanner sc) {
        System.out.print("Enter ID to update: ");
        int id = sc.nextInt();
        sc.nextLine(); // consume newline

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Contact contact = session.get(Contact.class, id);
        if (contact != null) {
            System.out.print("Enter new name: ");
            contact.setName(sc.nextLine());
            System.out.print("Enter new phone: ");
            contact.setPhone(sc.nextLine());
            System.out.print("Enter new email: ");
            contact.setEmail(sc.nextLine());
            session.update(contact);
            System.out.println("Contact updated successfully!");
        } else {
            System.out.println("Contact not found.");
        }
        tx.commit();
        session.close();
    }

    private static void displayContacts() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Contact> contacts = session.createQuery("from Contact", Contact.class).list();
        System.out.println("\n--- All Contacts ---");
        for (Contact c : contacts) {
            System.out.println("ID: " + c.getId() + ", Name: " + c.getName() +
                               ", Phone: " + c.getPhone() + ", Email: " + c.getEmail());
        }
        session.close();
    }
}
